Ecommerce Initialized
