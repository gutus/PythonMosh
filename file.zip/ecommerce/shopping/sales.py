#print("Sales initialized", __name__)


def calc_shipping():
    return "Ini contoh fungsi kalkulasi shipping"


def calc_tax():
    return "Ini contoh fungsi kalkulasi pajak"


if __name__ == "__main__":
    print("sales started")
    calc_tax()
