def contact_customer():
    return "Ini contoh fungsi Kontak Konsumen"


def ccontact_sales_point():
    return "Ini contoh fungsi Sales Point Konsumen"
